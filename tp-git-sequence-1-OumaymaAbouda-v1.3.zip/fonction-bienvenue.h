#ifndef FONCTION_BIENVENUE_H
#define FONCTION_BIENVENUE_H
#include <string>
void afficherBienvenue(std::string message="Bienvenue le monde !");
#endif // FONCTION_BIENVENUE_H
