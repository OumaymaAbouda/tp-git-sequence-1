# TP Git – Séquence 1

Correction du README pour documenter les modifications du code :
- Fonction `afficherBienvenue` modifiée pour accepter un message paramétrable.

