// Affiche un message de bienvenue
#include "fonction-bienvenue.h"
int main()
{
afficherBienvenue();
return 0;
}
